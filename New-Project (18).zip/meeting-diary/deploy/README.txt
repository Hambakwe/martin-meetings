MEETING DIARY - DEPLOYMENT GUIDE
=================================

Version: 26
Updated: 2026-02-03

QUICK START
-----------
1. Upload ALL files from this folder to your web root
2. Run schema.sql on your MariaDB database
3. Update api/config.php with your DB credentials if different
4. Run reset_admin_password.php in browser to set admin password
5. DELETE reset_admin_password.php and debug.php after use!
6. Visit your website - login with: admin@meetings.com / Admin123!


DEBUGGING DATA ISSUES
---------------------
If data saves but doesn't display:

1. Visit: https://your-domain.com/api/debug.php
   - This shows database connection status
   - Shows table contents and record counts
   - Tests snake_case to camelCase conversion

2. Visit API endpoints directly in browser:
   - https://your-domain.com/api/persons.php
   - https://your-domain.com/api/hotels.php
   - https://your-domain.com/api/meetings.php

   These should return JSON arrays. If empty: []
   If error: {"error":true,"message":"..."}

3. Check browser console for JavaScript errors:
   - Right-click > Inspect > Console tab
   - Look for fetch errors or JSON parsing errors

4. DELETE debug.php and test.php after troubleshooting!


IMPORTANT: PASSWORD SETUP
-------------------------
After uploading files and running schema.sql, you MUST run the password
reset script to create a working admin account:

1. Visit: https://your-domain.com/reset_admin_password.php
2. It will create/update the admin user with the correct password hash
3. DELETE reset_admin_password.php immediately after!

Login credentials after running reset script:
- Email: admin@meetings.com
- Password: Admin123!


FILE STRUCTURE
--------------
deploy/
├── .htaccess                   <- Main Apache routing (IMPORTANT!)
├── index.html                  <- Main application
├── reset_admin_password.php    <- Run once then DELETE!
├── schema.sql                  <- Database schema
├── 404/                        <- 404 error page
├── _next/                      <- Static assets (CSS, JS)
└── api/                        <- PHP API backend
    ├── .htaccess               <- API routing
    ├── config.php              <- Database configuration (EDIT THIS!)
    ├── auth.php                <- Authentication API
    ├── persons.php             <- Persons CRUD
    ├── hotels.php              <- Hotels CRUD
    ├── meetings.php            <- Meetings CRUD
    ├── users.php               <- Users CRUD
    ├── debug.php               <- Debug tool (DELETE AFTER USE!)
    ├── test.php                <- Test tool (DELETE AFTER USE!)
    └── index.php               <- API info


DATABASE SETUP
--------------
Run schema.sql on your MariaDB database:

    mysql -u your_user -p your_database < schema.sql

This creates:
- users table (admin user created but needs password set)
- persons table
- hotels table
- meetings table


API CONFIGURATION
-----------------
Edit api/config.php and update these values:

    define('DB_HOST', 'localhost');
    define('DB_NAME', 'your_database_name');
    define('DB_USER', 'your_database_user');
    define('DB_PASS', 'your_database_password');

Current config uses:
- Database: oasiscapi_meetings
- User: oasiscapi_oasistravel


APACHE REQUIREMENTS
-------------------
- mod_rewrite enabled
- AllowOverride All in your virtual host config

To enable mod_rewrite:
    sudo a2enmod rewrite
    sudo systemctl restart apache2


TESTING API DIRECTLY
--------------------
You can test the API directly using curl:

# Get all persons
curl https://your-domain.com/api/persons.php

# Get all hotels
curl https://your-domain.com/api/hotels.php

# Get all meetings
curl https://your-domain.com/api/meetings.php

# Create a person
curl -X POST https://your-domain.com/api/persons.php \
  -H "Content-Type: application/json" \
  -d '{"name":"John Doe","email":"john@example.com"}'


TROUBLESHOOTING
---------------
Problem: "Invalid email or password"
Solution: Run reset_admin_password.php first!

Problem: Data saves but doesn't display
Solution:
1. Visit /api/debug.php to check database
2. Make sure API endpoints return valid JSON
3. Check browser console for errors

Problem: 500 Error
Solution: Check api/config.php database credentials

Problem: 404 Error
Solution: Make sure .htaccess files are uploaded and mod_rewrite enabled

Problem: CORS Error
Solution: Update CORS_ORIGIN in api/config.php to your domain


SUPPORT
-------
Default Login: admin@meetings.com / Admin123!
