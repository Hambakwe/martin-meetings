<?php
/**
 * Meeting Diary - Add Sample Data
 * Adds sample persons, hotels, and meetings for testing
 * DELETE THIS FILE AFTER TESTING!
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: text/html; charset=utf-8');

// Database config
$dbHost = 'localhost';
$dbName = 'oasiscapi_meetings';
$dbUser = 'oasiscapi_oasistravel';
$dbPass = 'C1nd3r3ll4!$';

echo "<!DOCTYPE html><html><head><title>Add Sample Data</title>";
echo "<style>body{font-family:-apple-system,sans-serif;max-width:800px;margin:40px auto;padding:20px;}";
echo ".success{color:#059669;}.error{color:#DC2626;}.info{color:#2563eb;}";
echo "pre{background:#f4f4f5;padding:12px;border-radius:8px;}";
echo "h2{color:#0f766e;border-bottom:2px solid #0d9488;padding-bottom:8px;}</style></head><body>";

echo "<h1>Meeting Diary - Add Sample Data</h1>";

try {
    $pdo = new PDO(
        "mysql:host=$dbHost;dbname=$dbName;charset=utf8mb4",
        $dbUser,
        $dbPass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    echo "<p class='success'>✓ Database connected</p>";
} catch (PDOException $e) {
    echo "<p class='error'>✗ Database Error: " . htmlspecialchars($e->getMessage()) . "</p>";
    exit;
}

// Helper function to generate ID
function generateId() {
    return uniqid() . '-' . bin2hex(random_bytes(4));
}

// =====================================================
// SAMPLE PERSONS
// =====================================================
echo "<h2>1. Adding Sample Persons</h2>";

$persons = [
    [
        'name' => 'John Smith',
        'email' => 'john.smith@example.com',
        'company' => 'Acme Corporation',
        'role' => 'Sales Director',
        'phone' => '+1 555-123-4567',
        'notes' => 'Key account manager for Europe region'
    ],
    [
        'name' => 'Maria Garcia',
        'email' => 'maria.garcia@travelco.com',
        'company' => 'TravelCo International',
        'role' => 'Product Manager',
        'phone' => '+34 612 345 678',
        'notes' => 'Handles Mediterranean destinations'
    ],
    [
        'name' => 'Hans Mueller',
        'email' => 'h.mueller@germantours.de',
        'company' => 'German Tours GmbH',
        'role' => 'CEO',
        'phone' => '+49 30 12345678',
        'notes' => 'Decision maker, prefers morning meetings'
    ],
    [
        'name' => 'Sophie Chen',
        'email' => 'sophie.chen@asiapacific.com',
        'company' => 'Asia Pacific Travel',
        'role' => 'Regional Director',
        'phone' => '+852 9876 5432',
        'notes' => 'Focuses on luxury travel segment'
    ],
    [
        'name' => 'Ahmed Hassan',
        'email' => 'ahmed@middleeasttours.ae',
        'company' => 'Middle East Tours',
        'role' => 'Business Development',
        'phone' => '+971 50 123 4567',
        'notes' => 'New partner, interested in European packages'
    ]
];

$personIds = [];
$stmt = $pdo->prepare('
    INSERT INTO persons (id, name, email, company, role, phone, notes)
    VALUES (?, ?, ?, ?, ?, ?, ?)
');

foreach ($persons as $person) {
    $id = generateId();
    $personIds[] = $id;
    try {
        $stmt->execute([
            $id,
            $person['name'],
            $person['email'],
            $person['company'],
            $person['role'],
            $person['phone'],
            $person['notes']
        ]);
        echo "<p class='success'>✓ Added: {$person['name']}</p>";
    } catch (PDOException $e) {
        echo "<p class='error'>✗ Failed to add {$person['name']}: " . $e->getMessage() . "</p>";
    }
}

// =====================================================
// SAMPLE HOTELS
// =====================================================
echo "<h2>2. Adding Sample Hotels</h2>";

$hotels = [
    [
        'name' => 'Grand Hotel Excelsior',
        'country' => 'Switzerland',
        'city' => 'Zurich',
        'area' => 'City Center',
        'full_address' => 'Bahnhofstrasse 45, 8001 Zurich, Switzerland',
        'latitude' => 47.3769,
        'longitude' => 8.5417
    ],
    [
        'name' => 'Hotel Ritz Paris',
        'country' => 'France',
        'city' => 'Paris',
        'area' => 'Place Vendome',
        'full_address' => '15 Place Vendôme, 75001 Paris, France',
        'latitude' => 48.8682,
        'longitude' => 2.3292
    ],
    [
        'name' => 'The Savoy',
        'country' => 'United Kingdom',
        'city' => 'London',
        'area' => 'Strand',
        'full_address' => 'Strand, London WC2R 0EZ, United Kingdom',
        'latitude' => 51.5099,
        'longitude' => -0.1204
    ],
    [
        'name' => 'Hotel Danieli',
        'country' => 'Italy',
        'city' => 'Venice',
        'area' => 'San Marco',
        'full_address' => 'Riva degli Schiavoni 4196, 30122 Venice, Italy',
        'latitude' => 45.4337,
        'longitude' => 12.3440
    ],
    [
        'name' => 'Burj Al Arab',
        'country' => 'United Arab Emirates',
        'city' => 'Dubai',
        'area' => 'Jumeirah',
        'full_address' => 'Jumeirah Beach Road, Dubai, UAE',
        'latitude' => 25.1412,
        'longitude' => 55.1853
    ],
    [
        'name' => 'Marina Bay Sands',
        'country' => 'Singapore',
        'city' => 'Singapore',
        'area' => 'Marina Bay',
        'full_address' => '10 Bayfront Avenue, Singapore 018956',
        'latitude' => 1.2834,
        'longitude' => 103.8607
    ]
];

$hotelIds = [];
$stmt = $pdo->prepare('
    INSERT INTO hotels (id, name, country, city, area, full_address, latitude, longitude)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
');

foreach ($hotels as $hotel) {
    $id = generateId();
    $hotelIds[] = $id;
    try {
        $stmt->execute([
            $id,
            $hotel['name'],
            $hotel['country'],
            $hotel['city'],
            $hotel['area'],
            $hotel['full_address'],
            $hotel['latitude'],
            $hotel['longitude']
        ]);
        echo "<p class='success'>✓ Added: {$hotel['name']} ({$hotel['city']})</p>";
    } catch (PDOException $e) {
        echo "<p class='error'>✗ Failed to add {$hotel['name']}: " . $e->getMessage() . "</p>";
    }
}

// =====================================================
// SAMPLE MEETINGS
// =====================================================
echo "<h2>3. Adding Sample Meetings</h2>";

// Get existing person IDs if we have any
$existingPersons = $pdo->query('SELECT id, name FROM persons')->fetchAll();
$existingHotels = $pdo->query('SELECT id, name FROM hotels')->fetchAll();

if (count($existingPersons) < 2 || count($existingHotels) < 2) {
    echo "<p class='error'>Need at least 2 persons and 2 hotels to create meetings</p>";
} else {
    $meetings = [
        [
            'title' => 'Q1 Partnership Review',
            'person_id' => $existingPersons[0]['id'],
            'hotel_id' => $existingHotels[0]['id'],
            'destination' => $existingHotels[0]['name'],
            'from_date' => date('Y-m-d', strtotime('+7 days')),
            'to_date' => date('Y-m-d', strtotime('+8 days')),
            'notes' => 'Discuss Q1 results and Q2 targets',
            'status' => 'scheduled'
        ],
        [
            'title' => 'Product Launch Meeting',
            'person_id' => $existingPersons[1]['id'],
            'hotel_id' => $existingHotels[1]['id'],
            'destination' => $existingHotels[1]['name'],
            'from_date' => date('Y-m-d', strtotime('+14 days')),
            'to_date' => date('Y-m-d', strtotime('+16 days')),
            'notes' => 'New summer collection presentation',
            'status' => 'scheduled'
        ],
        [
            'title' => 'Annual Strategy Conference',
            'person_id' => $existingPersons[min(2, count($existingPersons)-1)]['id'],
            'hotel_id' => $existingHotels[min(2, count($existingHotels)-1)]['id'],
            'destination' => $existingHotels[min(2, count($existingHotels)-1)]['name'],
            'from_date' => date('Y-m-d', strtotime('+30 days')),
            'to_date' => date('Y-m-d', strtotime('+32 days')),
            'notes' => '3-day strategy planning session',
            'status' => 'scheduled'
        ],
        [
            'title' => 'Contract Negotiation',
            'person_id' => $existingPersons[min(3, count($existingPersons)-1)]['id'],
            'hotel_id' => $existingHotels[min(3, count($existingHotels)-1)]['id'],
            'destination' => $existingHotels[min(3, count($existingHotels)-1)]['name'],
            'from_date' => date('Y-m-d', strtotime('-10 days')),
            'to_date' => date('Y-m-d', strtotime('-9 days')),
            'notes' => 'Successfully closed new partnership deal',
            'status' => 'completed'
        ],
        [
            'title' => 'Market Research Tour',
            'person_id' => $existingPersons[min(4, count($existingPersons)-1)]['id'],
            'hotel_id' => $existingHotels[min(4, count($existingHotels)-1)]['id'],
            'destination' => $existingHotels[min(4, count($existingHotels)-1)]['name'],
            'from_date' => date('Y-m-d', strtotime('-5 days')),
            'to_date' => date('Y-m-d', strtotime('-3 days')),
            'notes' => 'Cancelled due to scheduling conflict',
            'status' => 'cancelled'
        ]
    ];

    $stmt = $pdo->prepare('
        INSERT INTO meetings (id, title, person_id, hotel_id, destination, from_date, to_date, notes, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ');

    foreach ($meetings as $meeting) {
        $id = generateId();
        try {
            $stmt->execute([
                $id,
                $meeting['title'],
                $meeting['person_id'],
                $meeting['hotel_id'],
                $meeting['destination'],
                $meeting['from_date'],
                $meeting['to_date'],
                $meeting['notes'],
                $meeting['status']
            ]);
            echo "<p class='success'>✓ Added: {$meeting['title']} ({$meeting['status']})</p>";
        } catch (PDOException $e) {
            echo "<p class='error'>✗ Failed to add {$meeting['title']}: " . $e->getMessage() . "</p>";
        }
    }
}

// =====================================================
// SUMMARY
// =====================================================
echo "<h2>Summary</h2>";

$counts = [];
foreach (['persons', 'hotels', 'meetings'] as $table) {
    $count = $pdo->query("SELECT COUNT(*) FROM $table")->fetchColumn();
    $counts[$table] = $count;
    echo "<p class='info'>$table: <strong>$count records</strong></p>";
}

echo "<hr>";
echo "<p><a href='/' style='color:#0d9488;font-weight:bold;'>← Go to Meeting Diary App</a></p>";
echo "<p class='error' style='font-weight:bold;'>⚠️ DELETE THIS FILE (add_sample_data.php) AFTER TESTING!</p>";
echo "</body></html>";
?>
