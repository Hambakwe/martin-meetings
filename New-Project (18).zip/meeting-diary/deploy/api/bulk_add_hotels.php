<?php
/**
 * Meeting Diary - Bulk Add Hotels
 * Add multiple hotels at once with a shared country
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database config
$dbHost = 'localhost';
$dbName = 'oasiscapi_meetings';
$dbUser = 'oasiscapi_oasistravel';
$dbPass = 'C1nd3r3ll4!$';

// Countries list
$countries = [
    "Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Argentina", "Armenia", "Australia",
    "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium",
    "Belize", "Benin", "Bhutan", "Bolivia", "Bosnia and Herzegovina", "Botswana", "Brazil", "Brunei",
    "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde",
    "Central African Republic", "Chad", "Chile", "China", "Colombia", "Comoros", "Congo", "Costa Rica",
    "Croatia", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic",
    "East Timor", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Eswatini",
    "Ethiopia", "Fiji", "Finland", "France", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Greece",
    "Grenada", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Honduras", "Hungary", "Iceland",
    "India", "Indonesia", "Iran", "Iraq", "Ireland", "Israel", "Italy", "Ivory Coast", "Jamaica", "Japan",
    "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Kuwait", "Kyrgyzstan", "Laos", "Latvia", "Lebanon",
    "Lesotho", "Liberia", "Libya", "Liechtenstein", "Lithuania", "Luxembourg", "Madagascar", "Malawi",
    "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Mauritania", "Mauritius", "Mexico",
    "Micronesia", "Moldova", "Monaco", "Mongolia", "Montenegro", "Morocco", "Mozambique", "Myanmar",
    "Namibia", "Nauru", "Nepal", "Netherlands", "New Zealand", "Nicaragua", "Niger", "Nigeria",
    "North Korea", "North Macedonia", "Norway", "Oman", "Pakistan", "Palau", "Palestine", "Panama",
    "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Poland", "Portugal", "Qatar", "Romania",
    "Russia", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines",
    "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Serbia", "Seychelles",
    "Sierra Leone", "Singapore", "Slovakia", "Slovenia", "Solomon Islands", "Somalia", "South Africa",
    "South Korea", "South Sudan", "Spain", "Sri Lanka", "Sudan", "Suriname", "Sweden", "Switzerland",
    "Syria", "Taiwan", "Tajikistan", "Tanzania", "Thailand", "Togo", "Tonga", "Trinidad and Tobago",
    "Tunisia", "Turkey", "Turkmenistan", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates",
    "United Kingdom", "United States", "Uruguay", "Uzbekistan", "Vanuatu", "Vatican City", "Venezuela",
    "Vietnam", "Yemen", "Zambia", "Zimbabwe"
];

// Generate unique ID
function generateId() {
    return uniqid() . '-' . bin2hex(random_bytes(4));
}

$message = '';
$messageType = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo = new PDO(
            "mysql:host=$dbHost;dbname=$dbName;charset=utf8mb4",
            $dbUser,
            $dbPass,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );

        $country = $_POST['country'] ?? '';
        $city = trim($_POST['city'] ?? '');
        $names = $_POST['names'] ?? [];

        if (empty($country)) {
            throw new Exception('Please select a country');
        }

        if (empty($city)) {
            throw new Exception('Please enter a city');
        }

        // Filter out empty names
        $names = array_filter($names, function($name) {
            return trim($name) !== '';
        });

        if (empty($names)) {
            throw new Exception('Please enter at least one hotel name');
        }

        $stmt = $pdo->prepare('
            INSERT INTO hotels (id, name, country, city, area, full_address, latitude, longitude)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ');

        $insertedCount = 0;
        foreach ($names as $name) {
            $id = generateId();
            $hotelName = trim($name);
            $stmt->execute([
                $id,
                $hotelName,
                $country,
                $city,
                null,                                       // area
                $hotelName . ', ' . $city . ', ' . $country, // full_address
                null,                                       // latitude
                null                                        // longitude
            ]);
            $insertedCount++;
        }

        $message = "Successfully added $insertedCount hotel(s) in $city, $country!";
        $messageType = 'success';

    } catch (Exception $e) {
        $message = "Error: " . $e->getMessage();
        $messageType = 'error';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bulk Add Hotels - Meeting Diary</title>
    <style>
        * { box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            max-width: 600px;
            margin: 40px auto;
            padding: 20px;
            background: linear-gradient(135deg, #faf5ff 0%, #f0fdfa 100%);
            min-height: 100vh;
        }
        .card {
            background: white;
            border-radius: 16px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            padding: 32px;
        }
        h1 {
            color: #7c3aed;
            margin: 0 0 8px 0;
            font-size: 24px;
        }
        .subtitle {
            color: #64748b;
            margin-bottom: 24px;
        }
        label {
            display: block;
            font-weight: 600;
            color: #374151;
            margin-bottom: 6px;
        }
        select, input[type="text"] {
            width: 100%;
            padding: 12px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.2s;
        }
        select:focus, input[type="text"]:focus {
            outline: none;
            border-color: #7c3aed;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .names-container {
            display: none;
            flex-direction: column;
            gap: 12px;
            margin-bottom: 20px;
            padding: 16px;
            background: #f8fafc;
            border-radius: 8px;
        }
        .names-container.visible {
            display: flex;
        }
        .name-input {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .name-input span {
            min-width: 24px;
            height: 24px;
            background: #7c3aed;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: bold;
        }
        .name-input input {
            flex: 1;
        }
        button {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #7c3aed 0%, #a855f7 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.1s, box-shadow 0.2s;
        }
        button:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(124, 58, 237, 0.4);
        }
        button:disabled {
            background: #9ca3af;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }
        .message {
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        .message.success {
            background: #d1fae5;
            color: #065f46;
            border: 1px solid #6ee7b7;
        }
        .message.error {
            background: #fee2e2;
            color: #991b1b;
            border: 1px solid #fca5a5;
        }
        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #7c3aed;
            text-decoration: none;
            font-weight: 500;
        }
        .back-link:hover {
            text-decoration: underline;
        }
        .info-box {
            margin-top: 16px;
            padding: 12px;
            background: #ede9fe;
            border-radius: 8px;
            font-size: 14px;
            color: #5b21b6;
        }
        .info-box strong {
            display: block;
            margin-bottom: 4px;
        }
        .delete-warning {
            margin-top: 24px;
            padding: 12px;
            background: #fef3c7;
            border: 1px solid #f59e0b;
            border-radius: 8px;
            color: #92400e;
            font-size: 14px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="card">
        <h1>Bulk Add Hotels</h1>
        <p class="subtitle">Add multiple hotels at once for the same city and country</p>

        <?php if ($message): ?>
            <div class="message <?php echo $messageType; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <form method="POST" id="bulkForm">
            <div class="form-group">
                <label for="country">Country *</label>
                <select name="country" id="country" required>
                    <option value="">-- Select Country --</option>
                    <?php foreach ($countries as $country): ?>
                        <option value="<?php echo htmlspecialchars($country); ?>">
                            <?php echo htmlspecialchars($country); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="city">City *</label>
                <input type="text" name="city" id="city" placeholder="Enter city name" required>
            </div>

            <div class="form-group">
                <label for="count">Number of Hotels to Add</label>
                <select name="count" id="count" onchange="updateNameFields()">
                    <option value="">-- Select --</option>
                    <?php for ($i = 2; $i <= 10; $i++): ?>
                        <option value="<?php echo $i; ?>"><?php echo $i; ?> hotels</option>
                    <?php endfor; ?>
                </select>
            </div>

            <div class="names-container" id="namesContainer">
                <label>Enter Hotel Names</label>
                <div id="nameFields"></div>
            </div>

            <button type="submit" id="submitBtn" disabled>Add Hotels</button>

            <div class="info-box">
                <strong>Note:</strong>
                Hotels will be created with the selected country and city. Address will be auto-generated.
                You can edit each hotel later in the app to add area and exact location coordinates.
            </div>
        </form>

        <a href="/" class="back-link">← Back to Meeting Diary</a>

        <div class="delete-warning">
            ⚠️ Delete this file (bulk_add_hotels.php) when no longer needed!
        </div>
    </div>

    <script>
        function updateNameFields() {
            const count = parseInt(document.getElementById('count').value) || 0;
            const container = document.getElementById('namesContainer');
            const fieldsDiv = document.getElementById('nameFields');
            const submitBtn = document.getElementById('submitBtn');

            if (count >= 2) {
                container.classList.add('visible');
                submitBtn.disabled = false;

                let html = '';
                for (let i = 1; i <= count; i++) {
                    html += `
                        <div class="name-input">
                            <span>${i}</span>
                            <input type="text" name="names[]" placeholder="Hotel name ${i}" required>
                        </div>
                    `;
                }
                fieldsDiv.innerHTML = html;
            } else {
                container.classList.remove('visible');
                fieldsDiv.innerHTML = '';
                submitBtn.disabled = true;
            }
        }
    </script>
</body>
</html>
