<?php
/**
 * Clear PHP OPcache
 * DELETE THIS FILE AFTER USE!
 */

header('Content-Type: text/html; charset=utf-8');

echo "<h1>Clear PHP Cache</h1>";

// Clear OPcache
if (function_exists('opcache_reset')) {
    if (opcache_reset()) {
        echo "<p style='color:green'>✓ OPcache cleared successfully!</p>";
    } else {
        echo "<p style='color:orange'>⚠ OPcache reset returned false</p>";
    }
} else {
    echo "<p style='color:gray'>OPcache not available</p>";
}

// Invalidate specific files
$files = [
    __DIR__ . '/config.php',
    __DIR__ . '/persons.php',
    __DIR__ . '/hotels.php',
    __DIR__ . '/meetings.php',
];

echo "<h2>Invalidating cached files:</h2>";
foreach ($files as $file) {
    if (function_exists('opcache_invalidate')) {
        opcache_invalidate($file, true);
        echo "<p>✓ Invalidated: " . basename($file) . "</p>";
    }
}

// Show OPcache status
if (function_exists('opcache_get_status')) {
    $status = opcache_get_status();
    if ($status) {
        echo "<h2>OPcache Status:</h2>";
        echo "<p>Enabled: " . ($status['opcache_enabled'] ? 'Yes' : 'No') . "</p>";
        echo "<p>Cached scripts: " . $status['opcache_statistics']['num_cached_scripts'] . "</p>";
    }
}

echo "<hr>";
echo "<p><a href='persons.php'>Test persons.php</a></p>";
echo "<p><a href='hotels.php'>Test hotels.php</a></p>";
echo "<p><a href='meetings.php'>Test meetings.php</a></p>";
echo "<p style='color:red;font-weight:bold;'>DELETE THIS FILE AFTER USE!</p>";
?>
