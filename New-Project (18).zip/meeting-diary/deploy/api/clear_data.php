<?php
/**
 * Meeting Diary - Clear Test Data
 * Removes all data from persons, hotels, and meetings tables
 * Keeps the admin user intact
 * DELETE THIS FILE AFTER TESTING!
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: text/html; charset=utf-8');

// Database config
$dbHost = 'localhost';
$dbName = 'oasiscapi_meetings';
$dbUser = 'oasiscapi_oasistravel';
$dbPass = 'C1nd3r3ll4!$';

// Check for confirmation parameter
$confirmed = isset($_GET['confirm']) && $_GET['confirm'] === 'yes';

echo "<!DOCTYPE html><html><head><title>Clear Test Data</title>";
echo "<style>body{font-family:-apple-system,sans-serif;max-width:800px;margin:40px auto;padding:20px;}";
echo ".success{color:#059669;}.error{color:#DC2626;}.warning{color:#D97706;}.info{color:#2563eb;}";
echo "pre{background:#f4f4f5;padding:12px;border-radius:8px;}";
echo "h2{color:#0f766e;border-bottom:2px solid #0d9488;padding-bottom:8px;}";
echo ".btn{display:inline-block;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:bold;margin:10px 10px 10px 0;}";
echo ".btn-danger{background:#dc2626;color:white;}.btn-cancel{background:#6b7280;color:white;}";
echo ".box{background:#fef3c7;border:2px solid #d97706;border-radius:8px;padding:20px;margin:20px 0;}";
echo "</style></head><body>";

echo "<h1>Meeting Diary - Clear Test Data</h1>";

try {
    $pdo = new PDO(
        "mysql:host=$dbHost;dbname=$dbName;charset=utf8mb4",
        $dbUser,
        $dbPass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    echo "<p class='success'>✓ Database connected</p>";
} catch (PDOException $e) {
    echo "<p class='error'>✗ Database Error: " . htmlspecialchars($e->getMessage()) . "</p>";
    exit;
}

// Show current counts
echo "<h2>Current Data</h2>";
$tables = [
    'meetings' => 'Meetings',
    'persons' => 'Persons',
    'hotels' => 'Hotels',
    'users' => 'Users (will keep admin)'
];

foreach ($tables as $table => $label) {
    $count = $pdo->query("SELECT COUNT(*) FROM $table")->fetchColumn();
    echo "<p class='info'>$label: <strong>$count records</strong></p>";
}

if (!$confirmed) {
    // Show confirmation dialog
    echo "<div class='box'>";
    echo "<h3 class='warning'>⚠️ Warning: This will delete all data!</h3>";
    echo "<p>This action will:</p>";
    echo "<ul>";
    echo "<li>Delete ALL meetings</li>";
    echo "<li>Delete ALL persons</li>";
    echo "<li>Delete ALL hotels</li>";
    echo "<li>Keep the admin user account</li>";
    echo "</ul>";
    echo "<p><strong>This cannot be undone!</strong></p>";
    echo "<a href='?confirm=yes' class='btn btn-danger'>Yes, Delete All Data</a>";
    echo "<a href='/' class='btn btn-cancel'>Cancel - Go Back</a>";
    echo "</div>";
} else {
    // Perform the deletion
    echo "<h2>Clearing Data...</h2>";

    // Order matters due to foreign keys
    $deleteOrder = ['meetings', 'persons', 'hotels'];

    foreach ($deleteOrder as $table) {
        try {
            $count = $pdo->query("SELECT COUNT(*) FROM $table")->fetchColumn();
            $pdo->exec("DELETE FROM $table");
            echo "<p class='success'>✓ Deleted $count records from $table</p>";
        } catch (PDOException $e) {
            echo "<p class='error'>✗ Failed to clear $table: " . $e->getMessage() . "</p>";
        }
    }

    // Verify deletion
    echo "<h2>Verification</h2>";
    foreach ($deleteOrder as $table) {
        $count = $pdo->query("SELECT COUNT(*) FROM $table")->fetchColumn();
        if ($count == 0) {
            echo "<p class='success'>✓ $table is empty</p>";
        } else {
            echo "<p class='warning'>⚠ $table still has $count records</p>";
        }
    }

    // Check admin user is still there
    $adminCount = $pdo->query("SELECT COUNT(*) FROM users WHERE email = 'admin@meetings.com'")->fetchColumn();
    if ($adminCount > 0) {
        echo "<p class='success'>✓ Admin user preserved</p>";
    } else {
        echo "<p class='warning'>⚠ Admin user not found - run reset_admin_password.php</p>";
    }

    echo "<hr>";
    echo "<p class='success' style='font-size:1.2em;'>✓ All test data has been cleared!</p>";
    echo "<p><a href='/' style='color:#0d9488;font-weight:bold;'>← Go to Meeting Diary App</a></p>";
    echo "<p><a href='add_sample_data.php' style='color:#2563eb;'>Add sample data again</a></p>";
}

echo "<hr>";
echo "<p class='error' style='font-weight:bold;'>⚠️ DELETE THIS FILE (clear_data.php) AFTER TESTING!</p>";
echo "</body></html>";
?>
