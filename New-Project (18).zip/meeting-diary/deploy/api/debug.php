<?php
/**
 * Meeting Diary - Full API Debug Tool
 * Tests database connection, table structure, and all API endpoints
 * DELETE THIS FILE AFTER DEBUGGING!
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: text/html; charset=utf-8');

echo "<!DOCTYPE html><html><head><title>API Debug</title>";
echo "<style>body { font-family: -apple-system, sans-serif; max-width: 1000px; margin: 20px auto; padding: 20px; }";
echo ".success { color: #059669; } .error { color: #DC2626; } .warning { color: #D97706; }";
echo "pre { background: #f4f4f5; padding: 12px; border-radius: 8px; overflow-x: auto; }";
echo "h2 { border-bottom: 2px solid #0d9488; padding-bottom: 8px; color: #0f766e; }";
echo ".test-result { margin: 8px 0; padding: 8px; background: #f8fafc; border-radius: 4px; }";
echo "</style></head><body>";

echo "<h1>Meeting Diary - API Debug Tool</h1>";

// Database config
$dbHost = 'localhost';
$dbName = 'oasiscapi_meetings';
$dbUser = 'oasiscapi_oasistravel';
$dbPass = 'C1nd3r3ll4!$';

echo "<h2>1. Database Connection</h2>";
$pdo = null;
try {
    $pdo = new PDO(
        "mysql:host=$dbHost;dbname=$dbName;charset=utf8mb4",
        $dbUser,
        $dbPass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
    echo "<div class='test-result success'>✓ Connected to database: $dbName</div>";
} catch (PDOException $e) {
    echo "<div class='test-result error'>✗ Connection failed: " . htmlspecialchars($e->getMessage()) . "</div>";
    echo "</body></html>";
    exit;
}

echo "<h2>2. Tables Check</h2>";
$tables = ['users', 'persons', 'hotels', 'meetings'];
foreach ($tables as $table) {
    $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
    if ($stmt->rowCount() > 0) {
        $count = $pdo->query("SELECT COUNT(*) FROM $table")->fetchColumn();
        echo "<div class='test-result success'>✓ Table '$table' exists - <strong>$count records</strong></div>";
    } else {
        echo "<div class='test-result error'>✗ Table '$table' NOT FOUND</div>";
    }
}

echo "<h2>3. Table Columns</h2>";
foreach ($tables as $table) {
    $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
    if ($stmt->rowCount() > 0) {
        $columns = [];
        $stmt = $pdo->query("DESCRIBE $table");
        while ($row = $stmt->fetch()) {
            $columns[] = $row['Field'];
        }
        echo "<div class='test-result'><strong>$table:</strong> " . implode(', ', $columns) . "</div>";
    }
}

// Convert snake_case to camelCase
function toCamelCase($data) {
    if (!is_array($data)) return $data;
    $result = [];
    foreach ($data as $key => $value) {
        $camelKey = lcfirst(str_replace('_', '', ucwords($key, '_')));
        $result[$camelKey] = is_array($value) ? toCamelCase($value) : $value;
    }
    return $result;
}

echo "<h2>4. Data Samples</h2>";

// Persons
echo "<h3>Persons Table</h3>";
$stmt = $pdo->query('SELECT * FROM persons LIMIT 3');
$persons = $stmt->fetchAll();
if (count($persons) > 0) {
    echo "<p>Raw database format:</p>";
    echo "<pre>" . htmlspecialchars(json_encode($persons[0], JSON_PRETTY_PRINT)) . "</pre>";
    echo "<p>After camelCase conversion (what API returns):</p>";
    echo "<pre>" . htmlspecialchars(json_encode(toCamelCase($persons[0]), JSON_PRETTY_PRINT)) . "</pre>";
} else {
    echo "<div class='test-result warning'>No persons in database</div>";
}

// Hotels
echo "<h3>Hotels Table</h3>";
$stmt = $pdo->query('SELECT * FROM hotels LIMIT 3');
$hotels = $stmt->fetchAll();
if (count($hotels) > 0) {
    echo "<p>Raw database format:</p>";
    echo "<pre>" . htmlspecialchars(json_encode($hotels[0], JSON_PRETTY_PRINT)) . "</pre>";
    echo "<p>After camelCase conversion:</p>";
    $converted = toCamelCase($hotels[0]);
    $converted['latitude'] = $converted['latitude'] ? (float)$converted['latitude'] : null;
    $converted['longitude'] = $converted['longitude'] ? (float)$converted['longitude'] : null;
    echo "<pre>" . htmlspecialchars(json_encode($converted, JSON_PRETTY_PRINT)) . "</pre>";
} else {
    echo "<div class='test-result warning'>No hotels in database</div>";
}

// Meetings
echo "<h3>Meetings Table</h3>";
$stmt = $pdo->query('SELECT * FROM meetings LIMIT 3');
$meetings = $stmt->fetchAll();
if (count($meetings) > 0) {
    echo "<p>Raw database format:</p>";
    echo "<pre>" . htmlspecialchars(json_encode($meetings[0], JSON_PRETTY_PRINT)) . "</pre>";
    echo "<p>After camelCase conversion:</p>";
    echo "<pre>" . htmlspecialchars(json_encode(toCamelCase($meetings[0]), JSON_PRETTY_PRINT)) . "</pre>";
} else {
    echo "<div class='test-result warning'>No meetings in database</div>";
}

echo "<h2>5. Direct API Endpoint Tests</h2>";

$baseUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];

$endpoints = [
    '/api/persons.php' => 'Persons API',
    '/api/hotels.php' => 'Hotels API',
    '/api/meetings.php' => 'Meetings API',
    '/api/auth.php' => 'Auth API (requires POST)',
];

echo "<p>Base URL: <code>$baseUrl</code></p>";
echo "<div class='test-result'>";
foreach ($endpoints as $path => $name) {
    $url = $baseUrl . $path;
    echo "<p><strong>$name:</strong> <a href='$url' target='_blank'>$url</a></p>";
}
echo "</div>";

echo "<h2>6. Test Fetch (JavaScript)</h2>";
echo "<p>Open browser console and run:</p>";
echo "<pre>
// Test persons API
fetch('/api/persons.php')
  .then(r => r.json())
  .then(data => console.log('Persons:', data))
  .catch(err => console.error('Error:', err));

// Test hotels API
fetch('/api/hotels.php')
  .then(r => r.json())
  .then(data => console.log('Hotels:', data))
  .catch(err => console.error('Error:', err));

// Test meetings API
fetch('/api/meetings.php')
  .then(r => r.json())
  .then(data => console.log('Meetings:', data))
  .catch(err => console.error('Error:', err));
</pre>";

echo "<h2>7. PHP Info Check</h2>";
echo "<div class='test-result'>";
echo "<p>PHP Version: " . phpversion() . "</p>";
echo "<p>PDO Drivers: " . implode(', ', PDO::getAvailableDrivers()) . "</p>";
echo "<p>JSON Extension: " . (extension_loaded('json') ? 'Loaded' : 'NOT LOADED') . "</p>";
echo "</div>";

echo "<hr>";
echo "<p class='error' style='font-weight: bold'>⚠️ DELETE THIS FILE (debug.php) AFTER TESTING!</p>";
echo "</body></html>";
?>
