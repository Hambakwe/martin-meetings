<?php
/**
 * API Diagnosis - Uses same config as API endpoints
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>API Diagnosis</h1>";
echo "<pre>";

// Load the same config as API
echo "1. Loading config.php...\n";
require_once __DIR__ . '/config.php';

echo "   DB_HOST: " . DB_HOST . "\n";
echo "   DB_NAME: " . DB_NAME . "\n";
echo "   DB_USER: " . DB_USER . "\n";
echo "   DB_PASS: " . (strlen(DB_PASS) > 0 ? "[SET - " . strlen(DB_PASS) . " chars]" : "[EMPTY]") . "\n\n";

// Test connection
echo "2. Testing database connection...\n";
try {
    $pdo = getDbConnection();
    echo "   ✓ Connected successfully\n\n";
} catch (Exception $e) {
    echo "   ✗ Connection failed: " . $e->getMessage() . "\n";
    exit;
}

// Test each table
$tables = ['persons', 'hotels', 'meetings'];

foreach ($tables as $table) {
    echo "3. Querying $table table...\n";
    try {
        $stmt = $pdo->query("SELECT * FROM $table");
        $rows = $stmt->fetchAll();
        echo "   ✓ Found " . count($rows) . " records\n";

        if (count($rows) > 0) {
            echo "   First record ID: " . $rows[0]['id'] . "\n";
            echo "   First record: " . json_encode($rows[0], JSON_PRETTY_PRINT) . "\n";
        }
        echo "\n";
    } catch (PDOException $e) {
        echo "   ✗ Query failed: " . $e->getMessage() . "\n\n";
    }
}

// Test the exact query from persons.php
echo "4. Testing exact persons.php query...\n";
try {
    $stmt = $pdo->query('SELECT * FROM persons ORDER BY name ASC');
    $persons = $stmt->fetchAll();
    echo "   Raw result count: " . count($persons) . "\n";
    echo "   Raw data:\n";
    print_r($persons);
} catch (PDOException $e) {
    echo "   ✗ Error: " . $e->getMessage() . "\n";
}

echo "\n5. Checking if tables exist in this database...\n";
$stmt = $pdo->query("SHOW TABLES");
$allTables = $stmt->fetchAll(PDO::FETCH_COLUMN);
echo "   Tables in " . DB_NAME . ": " . implode(", ", $allTables) . "\n";

echo "</pre>";
echo "<p style='color:red;font-weight:bold;'>DELETE THIS FILE AFTER DEBUGGING!</p>";
?>
