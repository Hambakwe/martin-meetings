<?php
// Simple API test - DELETE AFTER USE
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
echo json_encode([
    'status' => 'ok',
    'message' => 'API is working',
    'timestamp' => date('Y-m-d H:i:s'),
    'path' => $_SERVER['REQUEST_URI']
]);
