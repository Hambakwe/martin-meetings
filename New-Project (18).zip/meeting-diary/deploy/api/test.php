<?php
/**
 * API Diagnostic Test
 * Visit this file in your browser to test the database connection and API
 * DELETE THIS FILE AFTER TESTING!
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: text/html; charset=utf-8');

echo "<h1>Meeting Diary - API Diagnostic</h1>";

// Database config
$dbHost = 'localhost';
$dbName = 'oasiscapi_meetings';
$dbUser = 'oasiscapi_oasistravel';
$dbPass = 'C1nd3r3ll4!$';

echo "<h2>1. Database Connection</h2>";
try {
    $pdo = new PDO(
        "mysql:host=$dbHost;dbname=$dbName;charset=utf8mb4",
        $dbUser,
        $dbPass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    echo "<p style='color:green'>✓ Database connected successfully</p>";
} catch (PDOException $e) {
    echo "<p style='color:red'>✗ Database Error: " . htmlspecialchars($e->getMessage()) . "</p>";
    exit;
}

echo "<h2>2. Tables Check</h2>";
$tables = ['users', 'persons', 'hotels', 'meetings'];
foreach ($tables as $table) {
    $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
    if ($stmt->rowCount() > 0) {
        $count = $pdo->query("SELECT COUNT(*) FROM $table")->fetchColumn();
        echo "<p style='color:green'>✓ Table '$table' exists - $count rows</p>";
    } else {
        echo "<p style='color:red'>✗ Table '$table' NOT FOUND</p>";
    }
}

echo "<h2>3. Persons Data (Raw from Database)</h2>";
try {
    $stmt = $pdo->query('SELECT * FROM persons ORDER BY name ASC LIMIT 5');
    $persons = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($persons) > 0) {
        echo "<p>Found " . count($persons) . " person(s):</p>";
        echo "<pre>" . print_r($persons, true) . "</pre>";

        echo "<h3>Column Names:</h3>";
        echo "<pre>" . implode(', ', array_keys($persons[0])) . "</pre>";
    } else {
        echo "<p style='color:orange'>No persons in database</p>";
    }
} catch (PDOException $e) {
    echo "<p style='color:red'>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
}

echo "<h2>4. Testing API Response Format</h2>";

// Test camelCase conversion
function toCamelCase($data) {
    if (!is_array($data)) return $data;
    $result = [];
    foreach ($data as $key => $value) {
        $camelKey = lcfirst(str_replace('_', '', ucwords($key, '_')));
        $result[$camelKey] = is_array($value) ? toCamelCase($value) : $value;
    }
    return $result;
}

if (!empty($persons)) {
    $converted = toCamelCase($persons[0]);
    echo "<p>After camelCase conversion:</p>";
    echo "<pre>" . print_r($converted, true) . "</pre>";

    echo "<h3>JSON Output (what API should return):</h3>";
    $allConverted = array_map('toCamelCase', $persons);
    echo "<pre>" . json_encode($allConverted, JSON_PRETTY_PRINT) . "</pre>";
}

echo "<h2>5. Direct API Test</h2>";
$apiUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . '/api/persons.php';
echo "<p>Try visiting: <a href='$apiUrl' target='_blank'>$apiUrl</a></p>";

echo "<hr>";
echo "<p style='color:red; font-weight:bold'>DELETE THIS FILE (test.php) AFTER TESTING!</p>";
?>
