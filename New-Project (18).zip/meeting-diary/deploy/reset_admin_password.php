<?php
/**
 * Meeting Diary - Admin Password Reset Script
 *
 * Upload this file to your server and run it once to set the admin password.
 * DELETE THIS FILE AFTER USE for security!
 *
 * Usage: https://your-domain.com/reset_admin_password.php
 */

// Database Configuration - UPDATE THESE VALUES
$dbHost = 'localhost';
$dbName = 'oasiscapi_meetings';
$dbUser = 'oasiscapi_oasistravel';
$dbPass = 'C1nd3r3ll4!$';

// Admin credentials to set
$adminEmail = 'admin@meetings.com';
$adminPassword = 'Admin123!';
$adminName = 'Administrator';

echo "<h1>Meeting Diary - Admin Password Reset</h1>";

try {
    // Connect to database
    $pdo = new PDO(
        "mysql:host=$dbHost;dbname=$dbName;charset=utf8mb4",
        $dbUser,
        $dbPass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    echo "<p style='color:green'>✓ Database connection successful</p>";

    // Generate password hash
    $passwordHash = password_hash($adminPassword, PASSWORD_DEFAULT);
    echo "<p>Generated password hash for '$adminPassword'</p>";

    // Check if admin user exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$adminEmail]);
    $existingUser = $stmt->fetch();

    if ($existingUser) {
        // Update existing user
        $stmt = $pdo->prepare("UPDATE users SET password_hash = ?, name = ? WHERE email = ?");
        $stmt->execute([$passwordHash, $adminName, $adminEmail]);
        echo "<p style='color:green'>✓ Admin user password updated!</p>";
    } else {
        // Create new admin user
        $id = uniqid() . '-' . bin2hex(random_bytes(4));
        $stmt = $pdo->prepare("
            INSERT INTO users (id, name, email, password_hash, role)
            VALUES (?, ?, ?, ?, 'admin')
        ");
        $stmt->execute([$id, $adminName, $adminEmail, $passwordHash]);
        echo "<p style='color:green'>✓ Admin user created!</p>";
    }

    echo "<hr>";
    echo "<h2>Login Credentials</h2>";
    echo "<p><strong>Email:</strong> $adminEmail</p>";
    echo "<p><strong>Password:</strong> $adminPassword</p>";
    echo "<hr>";
    echo "<p style='color:red; font-weight:bold'>⚠️ DELETE THIS FILE NOW for security!</p>";
    echo "<p>Delete: reset_admin_password.php</p>";

} catch (PDOException $e) {
    echo "<p style='color:red'>✗ Database Error: " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p>Please check your database credentials in this file.</p>";
}
?>
