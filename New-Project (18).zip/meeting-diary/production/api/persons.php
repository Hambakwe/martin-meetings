<?php
/**
 * Meeting Diary - Persons API
 * Handles CRUD operations for persons/contacts
 */

require_once __DIR__ . '/config.php';

setCorsHeaders();

$method = $_SERVER['REQUEST_METHOD'];
$pdo = getDbConnection();

// Get ID from query string if present
$id = $_GET['id'] ?? null;

switch ($method) {
    case 'GET':
        if ($id) {
            // Get single person
            $stmt = $pdo->prepare('SELECT * FROM persons WHERE id = ?');
            $stmt->execute([$id]);
            $person = $stmt->fetch();

            if ($person) {
                sendResponse($person);
            } else {
                sendErrorResponse(404, 'Person not found');
            }
        } else {
            // Get all persons
            $stmt = $pdo->query('SELECT * FROM persons ORDER BY name ASC');
            $persons = $stmt->fetchAll();
            sendResponse($persons);
        }
        break;

    case 'POST':
        $data = getJsonInput();

        if (!validateRequired($data, ['name'])) {
            sendErrorResponse(400, 'Name is required');
        }

        $id = generateId();
        $stmt = $pdo->prepare('
            INSERT INTO persons (id, name, email, company, role, phone, notes, photo)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ');

        $stmt->execute([
            $id,
            $data['name'],
            $data['email'] ?? null,
            $data['company'] ?? null,
            $data['role'] ?? null,
            $data['phone'] ?? null,
            $data['notes'] ?? null,
            $data['photo'] ?? null,
        ]);

        // Return created person
        $stmt = $pdo->prepare('SELECT * FROM persons WHERE id = ?');
        $stmt->execute([$id]);
        $person = $stmt->fetch();

        sendResponse($person, 201);
        break;

    case 'PUT':
        if (!$id) {
            sendErrorResponse(400, 'Person ID is required');
        }

        $data = getJsonInput();

        if (!validateRequired($data, ['name'])) {
            sendErrorResponse(400, 'Name is required');
        }

        $stmt = $pdo->prepare('
            UPDATE persons
            SET name = ?, email = ?, company = ?, role = ?, phone = ?, notes = ?, photo = ?
            WHERE id = ?
        ');

        $stmt->execute([
            $data['name'],
            $data['email'] ?? null,
            $data['company'] ?? null,
            $data['role'] ?? null,
            $data['phone'] ?? null,
            $data['notes'] ?? null,
            $data['photo'] ?? null,
            $id,
        ]);

        if ($stmt->rowCount() === 0) {
            sendErrorResponse(404, 'Person not found');
        }

        // Return updated person
        $stmt = $pdo->prepare('SELECT * FROM persons WHERE id = ?');
        $stmt->execute([$id]);
        $person = $stmt->fetch();

        sendResponse($person);
        break;

    case 'DELETE':
        if (!$id) {
            sendErrorResponse(400, 'Person ID is required');
        }

        // Check if person has meetings
        $stmt = $pdo->prepare('SELECT COUNT(*) as count FROM meetings WHERE person_id = ?');
        $stmt->execute([$id]);
        $result = $stmt->fetch();

        if ($result['count'] > 0) {
            sendErrorResponse(400, 'Cannot delete person with existing meetings');
        }

        $stmt = $pdo->prepare('DELETE FROM persons WHERE id = ?');
        $stmt->execute([$id]);

        if ($stmt->rowCount() === 0) {
            sendErrorResponse(404, 'Person not found');
        }

        sendResponse(['success' => true, 'message' => 'Person deleted']);
        break;

    default:
        sendErrorResponse(405, 'Method not allowed');
}
